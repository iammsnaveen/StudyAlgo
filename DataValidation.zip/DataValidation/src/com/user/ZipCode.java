package com.user;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ZipCode implements IUserData {

	@Override
	public void isValid(String[] ZipCodes) {
		String patterns    = "^[1-9]{1}[0-9]{2}\\s{0,1}[0-9]{3}$";

	   

	    Pattern pattern = Pattern.compile(patterns);
	    for(String ZipCode : ZipCodes) {
	        Matcher matcher = pattern.matcher(ZipCode);
	        
if(matcher.matches()) {
	System.out.println("Valid ZipCode--->"+ZipCode);        	
	        }
else {
	System.out.println("*****InValid ZipCode-->"+ZipCode);     
}
	      
	        
	        
	    }

	}

}
