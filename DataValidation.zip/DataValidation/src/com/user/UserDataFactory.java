package com.user;

public class UserDataFactory {
	
public static IUserData verifyField(String strUserData) {
	if(strUserData.equalsIgnoreCase("PhoneNumber"))
		return new PhoneNumber();
	else if(strUserData.equalsIgnoreCase("ZipCode"))
		return new ZipCode();
	
	else if(strUserData.equalsIgnoreCase("PhoneNumber_India"))
		return new PhoneNumber_India();
	
	else if(strUserData.equalsIgnoreCase("Date"))
		return new Date();
	else return null;
	
}
	
	

}
