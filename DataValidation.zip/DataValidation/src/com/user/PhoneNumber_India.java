package com.user;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PhoneNumber_India implements IUserData {

	@Override
	public void isValid(String[] PhoneNumbers) {
		
	   
		
//		String patterns ="(0|91)?[7-9][0-9]{9}";
		
	    // 1) Begins with 0 or 91
	    // 2) Then contains 7 or 8 or 9.
	    // 3) Then contains 9 digits

	    
//		String patterns ="((\\+*)((0[ -]+)*|(91 )*)(\\d{12}+|\\d{10}+))|\\d{5}([- ]*)\\d{6}";
		String patterns ="^(\\+\\d{1,3}( )?)?((\\(\\d{3}\\))|\\d{3})[- .]?\\d{3}[- .]?\\d{4}$";

	    Pattern pattern = Pattern.compile(patterns);
	    for(String phoneNumber : PhoneNumbers) {
	        Matcher matcher = pattern.matcher(phoneNumber);
	        
if(matcher.matches()) {
	System.out.println("Valid INDIA PhoneNumber--->"+phoneNumber);    
	
//	System.out.println("***********  "+phoneNumber);     
	        }
else {
//	System.out.println("---------------------------------------------------------------------------------------------");   
	System.out.println("**********InValid INDIA PhoneNumber-->"+phoneNumber);   
//	System.out.println("---------------------------------------------------------------------------------------------");   
}
	      
	        
	        
	    }

	}

}
