package com.user;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PhoneNumber implements IUserData {

	@Override
	public void isValid(String[] PhoneNumbers) {
		String patterns 
	      = "^(\\+\\d{1,3}( )?)?((\\(\\d{3}\\))|\\d{3})[- .]?\\d{3}[- .]?\\d{4}$" 
	      + "|^(\\+\\d{1,3}( )?)?(\\d{3}[ ]?){2}\\d{3}$" 
	      + "|^(\\+\\d{1,3}( )?)?(\\d{3}[ ]?)(\\d{2}[ ]?){2}\\d{2}$";

	   

	    Pattern pattern = Pattern.compile(patterns);
	    for(String phoneNumber : PhoneNumbers) {
	        Matcher matcher = pattern.matcher(phoneNumber);
	        
if(matcher.matches()) {
	System.out.println("Valid PhoneNumber--->"+phoneNumber);        	
	        }
else {
//	System.out.println("---------------------------------------------------------------------------------------------");   
	System.out.println("******InValid PhoneNumber-->"+phoneNumber);  
//	System.out.println("---------------------------------------------------------------------------------------------");   
}
	      
	        
	        
	    }

	}

}
