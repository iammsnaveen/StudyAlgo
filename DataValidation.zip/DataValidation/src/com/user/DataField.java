package com.user;

public enum DataField {
	
	
	    PhoneNumber,
	    ZipCode,
	    PhoneNumber_India;

		
	

}
