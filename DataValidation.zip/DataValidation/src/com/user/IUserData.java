package com.user;

public interface IUserData {
	void isValid(String[] userData);
}


