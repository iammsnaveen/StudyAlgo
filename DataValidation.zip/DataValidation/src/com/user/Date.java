package com.user;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Date implements IUserData {

	@Override
	public void isValid(String[] Dates) {
		String patterns    = "\\(?:(?:(?:0[1-9]|1[0-2])\\(?:0[1-9]|1\\d|2[0-8])|(?:0[13-9]|1[0-2])\\(?:29|30)|(?:0[13578]|1[02])\\31)\\[1-9]\\d{3}|02\\29(?:\\[1-9]\\d(?:0[48]|[2468][048]|[13579][26])|(?:[2468][048]|[13579][26])00))";
				
				
//				"^((((0[1-9]|1[012])\\(?!00|29)([012]\\d)|(0[13-9]|1[012])\\(29|30)|(0[13578]|1[02])\\31)\\(18|19|20)\\d{2}|02\\29\\((18|19|20)(0[48]|[2468][048]|[13579][26])|2000)))$"
//						 + "|^(((\\d{4}-((0[13578]-|1[02]-)(0[1-9]|[12]\\d|3[01])|(0[13456789]-|1[012]-)(0[1-9]|[12]\\d|30)|02-(0[1-9]|1\\d|2[0-8])))|((([02468][048]|[13579][26])00|\\d{2}([13579][26]|0[48]|[2468][048])))-02-29)){0,10}$";
//		

	    Pattern pattern = Pattern.compile(patterns);
	    for(String Date : Dates) {
	        Matcher matcher = pattern.matcher(Date);
	        
if(matcher.matches()) {
	System.out.println("Valid Date--->"+Date);        	
	        }
else {
	System.out.println("*****InValid Date-->"+Date);     
}
	      
	        
	        
	    }

	}

}
