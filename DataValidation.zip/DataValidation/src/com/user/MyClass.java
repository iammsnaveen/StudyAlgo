package com.user;

public class MyClass {

	public static void main(String[] args) {
		
		
 String[] validPhoneNumbers = {"2055550125","202 555 0125", "(202) 555-0125", "+111 (202) 555-0125","636 856 789", "+111 636 856 789", "636 85 67 89", "+111 636 85 67 89"};
 String[] ValidZipCodes = {"560076","560 076","5600766","160076","9999999","-560076","+2560076","55560076","mmm0076","0060076","060076"};
 String[] ValidDates = {"12/07/2004","12/10/2010","5600766","10/01/2000","04/04/1998"};
 String[] validIndiaPhoneNumbers = {"7899354276","0 9754845789", "0-9778545896", "+91 9456211568", "91 9857842356", "919578965389", "0359-2595065", "01123456789777","900000000","9886153537"};
// 
 UserDataFactory.verifyField("PhoneNumber").isValid(validPhoneNumbers);	
 UserDataFactory.verifyField("PhoneNumber_India").isValid(validIndiaPhoneNumbers);
//UserDataFactory.verifyField("ZipCode").isValid(ValidZipCodes);
//UserDataFactory.verifyField("Date").isValid(ValidDates);

	}

}










